OpenScale
=======

![The electronics monitoring the bee hive](https://raw.githubusercontent.com/sparkfun/OpenScale/master/Hive-Electronics.jpg)

This project is still in prototyping phase. The firmware is very close to finished and we hope that you can learn and use it. 

You can read more about the beehive project that OpenScale is used in the [Internet of Bees](http://makezine.com/projects/bees-sensors-monitor-hive-health/) article.

OpenScale is an open source hardware load cell reader and calibration device. It has the ability to read multiple types of load cells and offers a simple to use serial menu to configure calibration value, sample rate, time stamp, and units of precision.

License Information
-------------------

This code is public domain but you buy me a beer if you use this and we meet someday ([Beerware license](http://en.wikipedia.org/wiki/Beerware)).

